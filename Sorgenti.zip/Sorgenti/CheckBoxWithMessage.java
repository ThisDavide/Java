import javax.swing.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class CheckBoxWithMessage {

    public static void main(String[] args) {
        // Creazione della finestra
        JFrame frame = new JFrame("Esempio di CheckBox con Messaggio");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Creazione della checkbox
        JCheckBox checkBox = new JCheckBox("Seleziona per vedere il messaggio");

        // Aggiungiamo un ascoltatore per il cambiamento dello stato della checkbox
        checkBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (checkBox.isSelected()) {
                    // Quando la checkbox è selezionata, mostriamo il messaggio con JOptionPane
                    JOptionPane.showMessageDialog(frame, "Hai selezionato la checkbox!");
                }
            }
        });

        // Aggiungiamo la checkbox alla finestra
        frame.add(checkBox);

        // Mostriamo la finestra
        frame.setVisible(true);
    }
}
