import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ComboBoxExample extends JFrame {
    public ComboBoxExample() {
        // Creazione di un JComboBox con alcune opzioni
        String[] options = {"Opzione 1", "Opzione 2", "Opzione 3"};
        JComboBox<String> comboBox = new JComboBox<>(options);

        // Etichetta per visualizzare la scelta
        JLabel label = new JLabel("Seleziona un'opzione");

        // Pulsante per visualizzare la scelta
        JButton button = new JButton("Mostra Selezione");

        // Azione quando si preme il bottone
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ottieni l'opzione selezionata dal JComboBox
                String selectedOption = (String) comboBox.getSelectedItem();
                label.setText("Hai selezionato: " + selectedOption);
            }
        });

        // Aggiungere i componenti alla finestra
        add(comboBox);
        add(button);
        add(label);

        setTitle("Esempio di JComboBox");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        setVisible(true);
    }

    public static void main(String[] args) {
        new ComboBoxExample();
    }
}