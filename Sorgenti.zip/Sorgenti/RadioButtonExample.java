import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RadioButtonExample extends JFrame { 
    public RadioButtonExample() {
    // Creazione dei radio button
    JRadioButton option1 = new JRadioButton("Opzione 1");
    JRadioButton option2 = new JRadioButton("Opzione 2");

    // Raggruppamento dei radio button in un ButtonGroup
    ButtonGroup group = new ButtonGroup();
    group.add(option1);
    group.add(option2);

    // Etichetta per visualizzare la scelta
    JLabel label = new JLabel("Seleziona un'opzione");

    // Pulsante per visualizzare la scelta
    JButton button = new JButton("Mostra Selezione");

    // Azione quando si preme il bottone
    button.addActionListener(new ActionListener() {
        @Override
            public void actionPerformed(ActionEvent e) {
                if (option1.isSelected()) {
                    label.setText("Hai selezionato: Opzione 1");
                } else if (option2.isSelected()) {
                    label.setText("Hai selezionato: Opzione 2");
                } else {
                    label.setText("Nessuna opzione selezionata");
                }
            }
        });

        // Aggiungere i componenti alla finestra
        add(option1);
        add(option2);
        add(button);
        add(label);

        setTitle("Esempio di RadioButton");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        setVisible(true);
    }
    
    public static void main(String[] args) {
        // Crea e mostra la finestra con i radio button
        new RadioButtonExample();
    }
}
