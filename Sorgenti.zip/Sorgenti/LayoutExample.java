import javax.swing.*;
import java.awt.*;

public class LayoutExample extends JFrame {

    // Costruttore della finestra
    public LayoutExample() {
        setTitle("Esempi di Layout");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Creiamo un JPanel per ogni layout
        JPanel borderPanel = createBorderLayoutPanel();
        JPanel flowPanel = createFlowLayoutPanel();
        JPanel gridPanel = createGridLayoutPanel();

        // Creiamo un JTabbedPane per visualizzare i diversi layout
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("BorderLayout", borderPanel);
        tabbedPane.addTab("FlowLayout", flowPanel);
        tabbedPane.addTab("GridLayout", gridPanel);

        // Aggiungiamo il JTabbedPane al JFrame
        add(tabbedPane);

        // Rendiamo la finestra visibile
        setVisible(true);
    }

    // Metodo per creare un JPanel con BorderLayout
    private JPanel createBorderLayoutPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Aggiungiamo componenti nelle diverse aree di BorderLayout
        panel.add(new JButton("Nord"), BorderLayout.NORTH);
        panel.add(new JButton("Sud"), BorderLayout.SOUTH);
        panel.add(new JButton("Est"), BorderLayout.EAST);
        panel.add(new JButton("Ovest"), BorderLayout.WEST);
        panel.add(new JButton("Centro"), BorderLayout.CENTER);

        return panel;
    }

    // Metodo per creare un JPanel con FlowLayout
    private JPanel createFlowLayoutPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout()); // Layout di default per JPanel è FlowLayout

        // Aggiungiamo alcuni pulsanti
        panel.add(new JButton("Pulsante 1"));
        panel.add(new JButton("Pulsante 2"));
        panel.add(new JButton("Pulsante 3"));
        panel.add(new JButton("Pulsante 4"));
        panel.add(new JButton("Pulsante 5"));

        return panel;
    }

    // Metodo per creare un JPanel con GridLayout
    private JPanel createGridLayoutPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2)); // 3 righe e 2 colonne

        // Aggiungiamo i pulsanti al layout
        panel.add(new JButton("1"));
        panel.add(new JButton("2"));
        panel.add(new JButton("3"));
        panel.add(new JButton("4"));
        panel.add(new JButton("5"));
        panel.add(new JButton("6"));

        return panel;
    }

    // Metodo main per lanciare l'applicazione
    public static void main(String[] args) {
        // Crea e mostra la finestra con i layout
        new LayoutExample();
    }
}
